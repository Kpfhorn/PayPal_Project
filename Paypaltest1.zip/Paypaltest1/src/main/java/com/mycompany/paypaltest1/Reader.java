package com.mycompany.paypaltest1;



public class Reader {
	public Reader() {
	}

	public void read() {
		
	}
}
